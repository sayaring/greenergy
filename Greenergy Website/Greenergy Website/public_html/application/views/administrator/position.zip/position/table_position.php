<hr style="margin-top: 0px !important;">
<table id="position_datatable" class="table table-striped dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;" >
</table>
                            

