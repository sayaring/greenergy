<?php  $this->load->view('frontend/includes/header', array()); ?>
		<h1><?php echo $heading; ?></h1>
		<?php echo $message; ?>
<?php   $this->load->view('frontend/includes/footer', array()); ?>