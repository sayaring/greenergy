<section class="cta-section">
        <div class="auto-container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <h2>Do You Have Product Related Query?</h2>
                </div>
                <div class="col-lg-5">
                    <div class="link-btn">
                        <a href="#" class="theme-btn"><span>Talk to Us</span></a>
                        <a href="tel:8250998973" class="theme-btn style-three"><span><i class="flaticon-phone-call"></i> +91-8250998973</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
